#pragma once
class UIManager
{
public:
	UIManager();
	~UIManager();

public:
	void GetInstance();
	void DestroyInstance();

	void MiniMapUpdate();
	void TimerUpdate();

	void MiniMapShow();
	//void ScoreBoardShow(); <- CJ ���� : score board ���°���???
	void TimerShow();
	void UserNumShow();
};

