#include "ClientPacketManager.h"

#include <string>

#include "ClientPakcetHandler.h"
#include "CSoundManager.h"

ClientPacketManager::ClientPacketManager()
{
	RegisterHandler();
}

void ClientPacketManager::GetInstance()
{
}

void ClientPacketManager::DestroyInstance()
{
}

void ClientPacketManager::HandlePacket(char* buffer)
{
	// ���ۿ��� ��Ŷ ��� ���� �� Ÿ�� Ȯ�� <- ù �κ��� PacketHeader��� ����
	PacketHeader* header = (PacketHeader*)buffer;
	PacketType type = header->type;

	// _handlers���� �ش� Ÿ���� �ڵ鷯 �Լ� ã��
	auto iter = _handlers.find(type);
	if (iter != _handlers.end())
	{
		iter->second(buffer);
	}
	else
	{
		// ���� ��Ŷ Ÿ��
		wstring debugMsg = L"[ClientPacketManager] ���� ��Ŷ type: " + to_wstring(static_cast<int>(type)) + L"\n";
		OutputDebugString(debugMsg.c_str());
	}
}

void ClientPacketManager::RegisterHandler()
{
	using namespace client::handler;

	_handlers[PacketType::MovePacket_s2c] = Handle_MovePacket_s2c;
	_handlers[PacketType::LoginAcceptPacket_s2c] = Handle_LoginAccept_s2c;
	_handlers[PacketType::AllPlayerMovePacket_s2c] = Handle_AllPlayerMovePacket_s2c;
	//_handlers[PacketType::MapLoadPacket_s2c] = Handle_MapLoad_s2c;
	//_handlers[PacketType::RoomEnterAcceptPacket_s2c] = Handle_RoomEnterAccept_s2c;
	_handlers[PacketType::RoomStartPacket_s2c] = Handle_RoomStart_s2c;
	_handlers[PacketType::SpawnOtherPlayerPacket_s2c] = SpawnOtherPlayerPacket_s2c;
	_handlers[PacketType::DespawnOtherPlayerPacket_s2c] = DespawnOtherPlayerPacket_s2c;
	//_handlers[PacketType::MapRoomEndPacket_s2c] = Handle_MapRoomEnd_s2c;
}